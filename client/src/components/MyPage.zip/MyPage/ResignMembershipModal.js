import style from './ResignMembershipModal.module.css'
function ResignMembershipModal(){
    return (
        <div>
            hi
        </div>
    )
}
export default ResignMembershipModal